/**
 * User.java.
 * Clase user para usar constructor
 * OAGS - 2021/22
 * version v1.0.0
 */
package Classes;


public class User

{
	public int id;
	public String username;
	public String name;
	public String email;
	public String nif;
	public String address;
	public String birthdate;
	public String role;
}

