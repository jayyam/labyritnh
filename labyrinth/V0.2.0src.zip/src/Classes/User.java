/**
 * User.java
 * Clase user para usar constructor
 * OAGS - 2021/22
 * version 0.2.0
 */
package Classes;


public class User

{
	public String username;
	public String name;
	public String age;
	public String DNI;
	public String email;
	public String address;
	public String birthdate;
	public String role;
}

